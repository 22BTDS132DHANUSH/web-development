async function sendMessage() {
    const userInput = document.getElementById('userInput').value;
    if (userInput) {
        addMessage(userInput, "You");
        document.getElementById('userInput').value = '';

        const thinkingElement = document.createElement('div');
        thinkingElement.innerHTML = "<strong>AI:</strong> Thinking...";
        messagesDiv.appendChild(thinkingElement);

        try {
            // Check for keywords related to esports finance
            const esportsTopics = ["sponsorship", "investment", "esports team", "player salary", "financial strategy"];
            const isEsportsRelated = esportsTopics.some(topic => userInput.toLowerCase().includes(topic));

            // If related to esports finance, add a custom instruction
            const systemMessage = isEsportsRelated
                ? "Respond with full, detailed information specifically tailored to esports finance."
                : "Answer the question briefly.";

            const response = await fetch("https://api.openai.com/v1/chat/completions", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${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}`
                },
                body: JSON.stringify({
                    model: "gpt-3.5-turbo",
                    messages: [
                        { role: "system", content: systemMessage },
                        { role: "user", content: userInput }
                    ]
                })
            });

            const data = await response.json();
            messagesDiv.removeChild(thinkingElement);
            const reply = data.choices[0].message.content;
            addMessage(reply, "AI");
        } catch (error) {
            console.error("Error:", error);
            messagesDiv.removeChild(thinkingElement);
            addMessage("Error connecting to the server. Please try again.", "AI");
        }
    }
}
