#include <iostream>
#include <cstdlib>

int main() {
    // Set the content type for HTML output
    std::cout << "Content-type: text/html\n\n";

    // HTML content that will be displayed when the user clicks the "Get Started" button
    std::cout << "<html><head><title>Sponsorship Form</title></head><body>";
    std::cout << "<h2>Submit Your Sponsorship or Investment Interest</h2>";
    
    // Form to capture sponsorship or investment details
    std::cout << "<form action='/cgi-bin/submit.cgi' method='post'>";
    std::cout << "Name: <input type='text' name='name'><br>";
    std::cout << "Email: <input type='email' name='email'><br>";
    std::cout << "Interest: <select name='interest'>";
    std::cout << "<option value='sponsor'>Sponsorship</option>";
    std::cout << "<option value='invest'>Investment</option>";
    std::cout << "</select><br>";
    std::cout << "<input type='submit' value='Submit'>";
    std::cout << "</form>";

    std::cout << "</body></html>";

    return 0;
}
