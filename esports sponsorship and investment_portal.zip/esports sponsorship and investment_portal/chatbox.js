const openaiApiKey = 'YOUR_API_KEY_HERE'; // Replace with your OpenAI API key

const messagesDiv = document.getElementById('messages');

function addMessage(content, sender) {
    const messageElement = document.createElement('div');
    messageElement.className = sender === "User" ? 'user-message' : 'ai-message';
    messageElement.textContent = content;
    messagesDiv.appendChild(messageElement);
    messagesDiv.scrollTop = messagesDiv.scrollHeight; // Scroll to the bottom
}

async function sendMessage() {
    const userInput = document.getElementById('userInput').value;
    if (!userInput.trim()) return; // Ignore empty messages

    addMessage(userInput, "User");
    document.getElementById('userInput').value = ''; // Clear input

    addMessage("Thinking...", "AI");
    const thinkingElement = messagesDiv.lastChild; // Get the "Thinking..." message

    try {
        const response = await fetch("https://api.openai.com/v1/chat/completions", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${openaiApiKey}`
            },
            body: JSON.stringify({
                model: "gpt-3.5-turbo",
                messages: [{ role: "user", content: userInput }]
            })
        });

        if (!response.ok) {
            const errorResponse = await response.json();
            throw new Error(`HTTP error! Status: ${response.status}, Message: ${errorResponse.error.message}`);
        }

        const data = await response.json();
        const botReply = data.choices[0].message.content; // Get the AI's response
        messagesDiv.removeChild(thinkingElement); // Remove "Thinking..." message
        addMessage(botReply, "AI");

    } catch (error) {
        console.error("Error:", error.message);
        messagesDiv.removeChild(thinkingElement);
        addMessage("Error connecting to the server: " + error.message, "AI");
    }
}

// Example static responses (if you don't want to use an external API)
const staticResponses = {
    "What is esports sponsorship?": "Esports sponsorship involves brands supporting esports teams or events financially, providing products, or offering services in exchange for exposure and marketing opportunities.",
    "What are the benefits of esports sponsorship?": "Benefits include increased brand visibility, engagement with a young audience, and association with popular games and events.",
    "How to invest in esports?": "Investing in esports can be done by purchasing shares in esports teams, funding tournaments, or investing in companies related to gaming and esports.",
    "What is the role of investors in esports?": "Investors provide financial backing for teams, events, and startups, helping to grow the esports ecosystem while seeking returns on their investments.",
    "How can I find sponsorship opportunities?": "You can find sponsorship opportunities by networking with esports organizations, attending events, and researching companies looking to engage with the esports community."
};

// Function to get static responses if the user input matches
function getStaticResponse(userInput) {
    const response = staticResponses[userInput];
    return response ? response : "I'm sorry, I don't have information on that topic. Please ask something else.";
}

// Overriding sendMessage to include static responses
async function sendMessage() {
    const userInput = document.getElementById('userInput').value;
    if (!userInput.trim()) return; // Ignore empty messages

    addMessage(userInput, "User");
    document.getElementById('userInput').value = ''; // Clear input

    addMessage("Thinking...", "AI");
    const thinkingElement = messagesDiv.lastChild; // Get the "Thinking..." message

    // Check for static responses first
    const staticReply = getStaticResponse(userInput);
    if (staticReply) {
        messagesDiv.removeChild(thinkingElement); // Remove "Thinking..." message
        addMessage(staticReply, "AI");
        return; // Stop further processing
    }

    // If no static response, proceed with API call
    try {
        const response = await fetch("https://api.openai.com/v1/chat/completions", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${openaiApiKey}`
            },
            body: JSON.stringify({
                model: "gpt-3.5-turbo",
                messages: [{ role: "user", content: userInput }]
            })
        });

        if (!response.ok) {
            const errorResponse = await response.json();
            throw new Error(`HTTP error! Status: ${response.status}, Message: ${errorResponse.error.message}`);
        }

        const data = await response.json();
        const botReply = data.choices[0].message.content; // Get the AI's response
        messagesDiv.removeChild(thinkingElement); // Remove "Thinking..." message
        addMessage(botReply, "AI");

    } catch (error) {
        console.error("Error:", error.message);
        messagesDiv.removeChild(thinkingElement);
        addMessage("Error connecting to the server: " + error.message, "AI");
    }
}
