const express = require('express');
const passport = require('passport');
const router = express.Router();

// Google Authentication Route
router.get('/auth/google', passport.authenticate('google', {
    scope: ['profile', 'email']
}));

// Facebook Authentication Route
router.get('/auth/facebook', passport.authenticate('facebook', {
    scope: ['email']
}));

// Callback routes for after the user authenticates
router.get('/auth/google/callback', 
    passport.authenticate('google', { failureRedirect: '/login' }),
    (req, res) => {
        // Successful authentication
        res.redirect('front.html'); // Redirect to home page after successful login
    }
);

router.get('/auth/facebook/callback', 
    passport.authenticate('facebook', { failureRedirect: '/login' }),
    (req, res) => {
        // Successful authentication
        res.redirect('front.html'); // Redirect to home page after successful login
    }
);

module.exports = router;
